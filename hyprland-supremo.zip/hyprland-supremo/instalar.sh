#!/usr/bin/env bash
set -euo pipefail
rice_root="$(cd -- "$(dirname -- "$0")" && pwd)"
config_only=false
case "${1:-}" in
    --config-only) config_only=true ;;
    "") ;;
    *) printf 'Uso: bash instalar.sh [--config-only]\n' >&2; exit 2 ;;
esac
if (( EUID == 0 )); then
    printf 'Execute com seu usuario normal: bash instalar.sh\n' >&2
    exit 1
fi
if [[ ! -f /etc/arch-release ]]; then
    printf 'Este instalador foi preparado para Arch Linux.\n' >&2
    exit 1
fi
if [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]] || pgrep -u "$(id -u)" -x Hyprland >/dev/null; then
    printf 'Saia da sessao Hyprland e execute pelo TTY (Ctrl+Alt+F3).\n' >&2
    printf 'Assim todas as configuracoes entram juntas no proximo login.\n' >&2
    exit 1
fi

if [[ "$config_only" == false ]]; then
    printf '\nInstalando o ambiente e os aplicativos do rice...\n'
    sudo pacman -Syu --needed \
        hyprland waybar wofi mako hyprlock hypridle hyprpolkitagent \
        xdg-desktop-portal-hyprland xdg-desktop-portal-gtk \
        alacritty thunar gvfs tumbler firefox neovim fastfetch \
        grim slurp wl-clipboard swaybg libnotify xdg-utils xdg-user-dirs \
        pipewire pipewire-pulse pipewire-alsa wireplumber pavucontrol \
        playerctl brightnessctl networkmanager \
        ttf-jetbrains-mono-nerd noto-fonts noto-fonts-emoji adwaita-icon-theme \
        python
fi

command -v python >/dev/null || { printf 'Instale o pacote python.\n' >&2; exit 1; }
hypr_version="$(pacman -Q hyprland | awk '{print $2}')"
if (( $(vercmp "$hypr_version" 0.56.0) < 0 )); then
    printf 'Este rice usa Lua e requer Hyprland 0.56 ou mais recente.\n' >&2
    exit 1
fi
python "$rice_root/tools/manage.py" install --source "$rice_root/config"

printf '\nSUPREMO instalado. Selecione Hyprland na tela de login.\n'
printf 'Pelo TTY, inicie com: start-hyprland\n'
printf 'Super+Enter: terminal | Super+D: aplicativos | Super+F1: atalhos\n'
printf 'Programacao e seus outros apps: bash instalar-apps-arch.sh\n'
