-- Opcional: coloca o tema supremo.lua como padrao no LazyVim.
return {
    { "LazyVim/LazyVim", opts = { colorscheme = "supremo" } },
}
