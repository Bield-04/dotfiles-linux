#!/usr/bin/env bash
set -euo pipefail
rice_root="$(cd -- "$(dirname -- "$0")" && pwd)"
if (( EUID == 0 )); then
    printf 'Execute com seu usuario normal: bash restaurar.sh\n' >&2
    exit 1
fi
if [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]] || pgrep -u "$(id -u)" -x Hyprland >/dev/null; then
    printf 'Saia da sessao Hyprland e execute a restauracao pelo TTY.\n' >&2
    exit 1
fi
if [[ -n "${1:-}" ]]; then
    exec python "$rice_root/tools/manage.py" restore --backup "$1"
fi
exec python "$rice_root/tools/manage.py" restore
