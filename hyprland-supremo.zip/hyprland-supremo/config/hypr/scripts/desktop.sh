#!/usr/bin/env bash
set -euo pipefail
config_root="${XDG_CONFIG_HOME:-$HOME/.config}"
state_root="${XDG_STATE_HOME:-$HOME/.local/state}/supremo"
mkdir -p "$state_root/logs"

menu() {
    wofi --conf "$config_root/wofi/config" --style "$config_root/wofi/style.css" "$@"
}

case "${1:-help}" in
    start)
        dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP HYPRLAND_INSTANCE_SIGNATURE 2>/dev/null || true
        systemctl --user start hyprpolkitagent.service 2>/dev/null || true
        systemctl --user start pipewire.socket pipewire-pulse.socket wireplumber.service 2>/dev/null || true
        "$0" bar >"$state_root/logs/waybar.log" 2>&1 &
        (
            exec 9>"$state_root/wallpaper.lock"
            flock -n 9 || exit 0
            exec swaybg -c '#0b0b0b' -i "$config_root/hypr/wallpapers/supremo.png" -m fill
        ) >"$state_root/logs/wallpaper.log" 2>&1 &
        if ! pgrep -xu "$(id -u)" mako >/dev/null; then
            mako --config "$config_root/mako/config" >"$state_root/logs/mako.log" 2>&1 &
        fi
        if ! pgrep -xu "$(id -u)" hypridle >/dev/null; then
            hypridle --config "$config_root/hypr/hypridle.conf" >"$state_root/logs/hypridle.log" 2>&1 &
        fi
        ;;
    bar)
        exec 9>"$state_root/waybar.lock"
        flock -n 9 || exit 0
        exec waybar --config "$config_root/waybar/config.jsonc" --style "$config_root/waybar/style.css"
        ;;
    menu)
        menu --show drun --prompt Aplicativos
        ;;
    reload)
        hyprctl reload
        pkill -USR2 -u "$(id -u)" -x waybar || true
        makoctl reload 2>/dev/null || true
        notify-send "Supremo" "Configurações recarregadas."
        ;;
    shot-area|shot-full)
        pictures="$(xdg-user-dir PICTURES 2>/dev/null || true)"
        pictures="${pictures:-$HOME/Pictures}"
        mkdir -p "$pictures/Capturas"
        target="$pictures/Capturas/captura-$(date +%Y%m%d-%H%M%S-%N).png"
        if [[ "$1" == "shot-area" ]]; then
            area="$(slurp -b 00000099 -c dddddddd)" || exit 0
            [[ -n "$area" ]] || exit 0
            grim -g "$area" "$target"
        else
            grim "$target"
        fi
        wl-copy --type image/png < "$target"
        notify-send "Captura salva e copiada" "$target"
        ;;
    power)
        action="$(printf '%s\n' 'Bloquear' 'Suspender' 'Sair da sessão' 'Reiniciar' 'Desligar' |
            menu --dmenu --prompt Sessão --height 330)" || exit 0
        case "$action" in
            Bloquear) exec hyprlock ;;
            Suspender)
                if ! pgrep -xu "$(id -u)" hypridle >/dev/null; then
                    notify-send "Supremo" "O hypridle precisa estar ativo para bloquear antes de suspender."
                    exit 1
                fi
                exec systemctl suspend
                ;;
            'Sair da sessão'|Reiniciar|Desligar)
                confirmed="$(printf '%s\n' 'Cancelar' 'Confirmar' |
                    menu --dmenu --prompt "$action?" --height 200)" || exit 0
                [[ "$confirmed" == "Confirmar" ]] || exit 0
                case "$action" in
                    'Sair da sessão')
                        if command -v hyprshutdown >/dev/null 2>&1; then
                            exec hyprshutdown
                        else
                            exec hyprctl dispatch 'hl.dsp.exit()'
                        fi
                        ;;
                    Reiniciar) exec systemctl reboot ;;
                    Desligar) exec systemctl poweroff ;;
                esac
                ;;
        esac
        ;;
    help)
        printf '%s\n' \
            'Super + Enter     Terminal' \
            'Super + D         Aplicativos' \
            'Super + B         Firefox' \
            'Super + E         Arquivos' \
            'Super + N         Neovim' \
            'Super + Q         Fechar janela' \
            'Super + F         Tela cheia' \
            'Super + V         Janela flutuante' \
            'Super + setas     Mudar foco' \
            'Super + Shift + setas   Mover janela' \
            'Super + 1 a 0     Áreas de trabalho' \
            'Super + Shift + 1 a 0   Enviar janela' \
            'Super + mouse     Mover / redimensionar' \
            'Super + L         Bloquear' \
            'Super + Esc       Menu da sessão' \
            'Super + Shift + R Recarregar' \
            'Print             Capturar região' \
            'Shift + Print     Capturar tela' \
            'Super = tecla Windows' |
            menu --dmenu --prompt Atalhos --height 620 >/dev/null || true
        ;;
    *) printf 'Ação desconhecida: %s\n' "$1" >&2; exit 2 ;;
esac
