-- SUPREMO | Gabriel | Arch Linux + Hyprland 0.56
-- Configuracao completa em Lua. Tecla principal: Super (Windows).
local config = os.getenv("XDG_CONFIG_HOME") or (os.getenv("HOME") .. "/.config")
local function quote(s) return "'" .. s:gsub("'", "'\\''") .. "'" end
local desktop = "bash " .. quote(config .. "/hypr/scripts/desktop.sh") .. " "
local function command(keys, cmd, flags)
    if flags then
        hl.bind(keys, hl.dsp.exec_cmd(cmd), flags)
    else
        hl.bind(keys, hl.dsp.exec_cmd(cmd))
    end
end

hl.env("XDG_CONFIG_HOME", config)
hl.env("XCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_SIZE", "24")
hl.env("GTK_THEME", "Adwaita:dark")

-- Descobre os monitores e usa a resolucao preferida de cada um.
hl.monitor({ output = "", mode = "preferred", position = "auto", scale = "auto" })

hl.config({
    general = {
        layout = "dwindle",
        gaps_in = 6,
        gaps_out = 16,
        border_size = 1,
        resize_on_border = true,
        col = {
            active_border = "rgba(bdbdbdff)",
            inactive_border = "rgba(353535ff)",
        },
    },
    decoration = {
        rounding = 10,
        active_opacity = 1.0,
        inactive_opacity = 1.0,
        shadow = { enabled = true, range = 14, render_power = 3, color = 0x60000000 },
        blur = { enabled = true, size = 3, passes = 1, vibrancy = 0.0 },
    },
    animations = { enabled = true },
    dwindle = { preserve_split = true },
    input = {
        kb_layout = "br",
        kb_variant = "",
        follow_mouse = 1,
        sensitivity = 0,
        touchpad = { natural_scroll = true, tap_to_click = true },
    },
    misc = {
        disable_hyprland_logo = true,
        disable_splash_rendering = true,
        background_color = "rgb(0b0b0b)",
        vfr = true,
    },
})

hl.curve("supremo", { type = "bezier", points = { {0.22, 1.0}, {0.36, 1.0} } })
hl.animation({ leaf = "windows", enabled = true, speed = 3, bezier = "supremo" })
hl.animation({ leaf = "fade", enabled = true, speed = 2, bezier = "supremo" })
hl.animation({ leaf = "border", enabled = true, speed = 2, bezier = "supremo" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 3, bezier = "supremo", style = "fade" })

hl.on("hyprland.start", function()
    hl.exec_cmd(desktop .. "start")
end)

command("SUPER + Return", "alacritty")
command("SUPER + D", desktop .. "menu")
command("SUPER + B", "firefox")
command("SUPER + E", "thunar")
command("SUPER + N", "alacritty -e nvim")
command("SUPER + L", "hyprlock")
command("SUPER + Escape", desktop .. "power")
command("SUPER + SHIFT + R", desktop .. "reload")
command("Print", desktop .. "shot-area")
command("SHIFT + Print", desktop .. "shot-full")
command("SUPER + F1", desktop .. "help")

hl.bind("SUPER + Q", hl.dsp.window.close())
hl.bind("SUPER + F", hl.dsp.window.fullscreen({ action = "toggle", mode = "fullscreen" }))
hl.bind("SUPER + V", hl.dsp.window.float({ action = "toggle" }))
hl.bind("SUPER + J", hl.dsp.layout("togglesplit"))

for _, direction in ipairs({ "left", "right", "up", "down" }) do
    hl.bind("SUPER + " .. direction, hl.dsp.focus({ direction = direction }))
    hl.bind("SUPER + SHIFT + " .. direction, hl.dsp.window.move({ direction = direction }))
end

for i = 1, 10 do
    local key = tostring(i % 10)
    hl.bind("SUPER + " .. key, hl.dsp.focus({ workspace = i }))
    hl.bind("SUPER + SHIFT + " .. key, hl.dsp.window.move({ workspace = i }))
end
hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })

local repeat_key = { repeating = true, locked = true }
command("XF86AudioRaiseVolume", "wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+", repeat_key)
command("XF86AudioLowerVolume", "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-", repeat_key)
command("XF86AudioMute", "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle", { locked = true })
command("XF86AudioMicMute", "wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle", { locked = true })
command("XF86MonBrightnessUp", "brightnessctl set +5%", repeat_key)
command("XF86MonBrightnessDown", "brightnessctl --min-value=1 set 5%-", repeat_key)
command("XF86AudioPlay", "playerctl play-pause", { locked = true })
command("XF86AudioPause", "playerctl play-pause", { locked = true })
command("XF86AudioNext", "playerctl next", { locked = true })
command("XF86AudioPrev", "playerctl previous", { locked = true })

hl.window_rule({
    name = "supremo-volume",
    match = { class = "^(org.pulseaudio.pavucontrol|pavucontrol)$" },
    float = true,
    size = { 760, 520 },
    center = true,
})

-- Ajustes pessoais opcionais, carregados por ultimo.
local userfile = config .. "/hypr/local.lua"
local f = io.open(userfile, "r")
if f then f:close(); dofile(userfile) end
