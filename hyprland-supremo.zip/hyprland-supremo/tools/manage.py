#!/usr/bin/env python3
"""Aplica o rice e restaura backups; usa somente a biblioteca padrao."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import uuid

MANAGED = ("hypr", "waybar", "wofi", "mako", "alacritty")


def exists(path):
    return os.path.lexists(path)


def stamp():
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temp.replace(path)


def copy_entry(source, target):
    if source.is_symlink():
        target.symlink_to(os.readlink(source))
    elif source.is_dir():
        shutil.copytree(source, target, symlinks=True)
    else:
        shutil.copy2(source, target, follow_symlinks=False)


def apply(source, config, state):
    for name in MANAGED:
        if not (source / name).is_dir() or (source / name).is_symlink():
            raise ValueError("Pasta do pacote ausente ou invalida: " + name)
    config.mkdir(parents=True, exist_ok=True)
    state.mkdir(parents=True, exist_ok=True)
    backup = state / "backups" / stamp()
    originals = backup / "original"
    originals.mkdir(parents=True, mode=0o700)
    backup.chmod(0o700)
    manifest = {
        "format": 1, "status": "preparing", "config_dir": str(config),
        "entries": {name: exists(config / name) for name in MANAGED},
    }
    write_json(backup / "manifest.json", manifest)
    completed = []
    stage = Path(tempfile.mkdtemp(prefix=".supremo-stage-", dir=config))
    try:
        for name in MANAGED:
            shutil.copytree(source / name, stage / name)
        for path in stage.rglob("*.sh"):
            path.chmod(0o755)
        for name in MANAGED:
            destination = config / name
            if manifest["entries"][name]:
                # os.replace move o proprio link, sem seguir o destino.
                os.replace(destination, originals / name)
            try:
                os.replace(stage / name, destination)
            except BaseException:
                if manifest["entries"][name]:
                    os.replace(originals / name, destination)
                raise
            completed.append(name)
            manifest["applied"] = completed.copy()
            write_json(backup / "manifest.json", manifest)
    except BaseException:
        for name in reversed(completed):
            os.replace(config / name, stage / ("failed-" + name))
            if manifest["entries"][name]:
                os.replace(originals / name, config / name)
        manifest["status"] = "rolled-back"
        write_json(backup / "manifest.json", manifest)
        raise
    finally:
        shutil.rmtree(stage)
    manifest["status"] = "complete"
    write_json(backup / "manifest.json", manifest)
    write_json(state / "latest.json", {"backup": str(backup)})
    print("Rice instalado em:", config)
    print("Backup:", backup)
    print("Para desfazer, execute: bash restaurar.sh")
    return backup


def restore(backup, config, state):
    manifest = json.loads((backup / "manifest.json").read_text())
    if manifest.get("format") != 1 or manifest.get("status") != "complete":
        raise ValueError("Backup incompleto ou formato desconhecido.")
    if Path(manifest.get("config_dir", "")).resolve() != config:
        raise ValueError("Este backup pertence a outro diretorio de configuracao.")
    entries = manifest.get("entries", {})
    if set(entries) != set(MANAGED) or any(type(v) is not bool for v in entries.values()):
        raise ValueError("Lista de arquivos do backup invalida.")
    for name in MANAGED:
        if entries[name] and not exists(backup / "original" / name):
            raise ValueError("Backup original ausente: " + name)
    config.mkdir(parents=True, exist_ok=True)
    archive = state / "antes-de-restaurar" / stamp()
    archive.mkdir(parents=True, mode=0o700)
    current = {name: exists(config / name) for name in MANAGED}
    stage = Path(tempfile.mkdtemp(prefix=".supremo-restore-", dir=config))
    completed = []
    try:
        for name in MANAGED:
            if entries[name]:
                copy_entry(backup / "original" / name, stage / name)
        for name in MANAGED:
            destination = config / name
            if current[name]:
                os.replace(destination, archive / name)
            try:
                if entries[name]:
                    os.replace(stage / name, destination)
            except BaseException:
                if current[name]:
                    os.replace(archive / name, destination)
                raise
            completed.append(name)
    except BaseException:
        for name in reversed(completed):
            if exists(config / name):
                os.replace(config / name, stage / ("failed-" + name))
            if current[name]:
                os.replace(archive / name, config / name)
        raise
    finally:
        shutil.rmtree(stage)
    write_json(archive / "restauracao.json", {"restored_from": str(backup)})
    print("Configuracoes anteriores restauradas.")
    print("As configuracoes que estavam em uso foram preservadas em:", archive)
    print("Entre novamente na sessao para aplicar a restauracao.")
    return archive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("install", "restore"))
    parser.add_argument("--source", type=Path)
    parser.add_argument("--backup", type=Path)
    parser.add_argument("--config-dir", type=Path, default=Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")))
    parser.add_argument("--state-dir", type=Path, default=Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local/state")) / "supremo")
    args = parser.parse_args()
    config, state = args.config_dir.expanduser().resolve(), args.state_dir.expanduser().resolve()
    if config == Path("/") or config == Path.home().resolve():
        parser.error("Escolha o diretorio de configuracao, como ~/.config.")
    if args.action == "install":
        if args.source is None:
            parser.error("--source e obrigatorio na instalacao.")
        apply(args.source.resolve(), config, state)
    else:
        backup = args.backup
        if backup is None:
            latest = state / "latest.json"
            if not latest.is_file():
                parser.error("Nenhum backup encontrado para este usuario.")
            backup = Path(json.loads(latest.read_text())["backup"])
        restore(backup.expanduser().resolve(), config, state)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as exc:
        print("Erro:", exc, file=sys.stderr)
        sys.exit(1)
