# SUPREMO — Hyprland do Gabriel

Rice monocromático para Arch Linux: preto, cinza e branco; bordas de 1 px,
cantos suaves, animações curtas, terminal escuro e barra compacta.

Preparado usando a configuração Lua do Hyprland 0.56.2. Requer Hyprland
0.56 ou mais recente; versões futuras podem mudar opções.

## Instalar

1. Termine a instalação do Arch e entre com seu usuário normal.
2. No Archinstall, escolher NetworkManager e PipeWire facilita o uso deste
   ambiente. O instalador do rice instala seus pacotes, mas não troca o serviço
   que gerencia sua rede.
3. Extraia este pacote. Saia de qualquer sessão Hyprland aberta.
4. Entre em um TTY com Ctrl+Alt+F3 ou use um terminal de outro ambiente.
5. Entre na pasta extraída e execute:

~~~bash
cd hyprland-supremo
bash instalar.sh
~~~

Execute sem sudo no começo do comando. O script pede a senha quando precisa
instalar os pacotes e mantém as confirmações do Pacman.

Depois, escolha **Hyprland** na tela de login. Se você usa somente TTY:

~~~bash
start-hyprland
~~~

O instalador não configura um gerenciador de login. A inicialização por TTY é
compatível com uma instalação mínima. Se não houver internet no menu de rede,
use o método de rede escolhido na instalação do Arch.

Se os pacotes já estiverem instalados, use:

~~~bash
bash instalar.sh --config-only
~~~

## O que vem pronto

| Componente | Configuração |
|---|---|
| Hyprland | Layout dwindle, monitor automático, teclado brasileiro, atalhos |
| Waybar | Áreas de trabalho, hora, CPU, RAM, áudio, rede e menu da sessão |
| Wofi | Menu de aplicativos e menu para sair, bloquear ou desligar |
| Mako | Notificações discretas, sem ícones coloridos |
| Alacritty | JetBrainsMono Nerd Font, paleta monocromática |
| Hyprlock | Relógio grande e campo de senha em cinza |
| Hypridle | Bloqueio após 10 minutos; monitores apagados após 15 minutos |
| Capturas | Print seleciona uma região; salva PNG e copia para o clipboard |
| Wallpaper | Arte vetorial original; versão PNG de 2560 × 1440 |
| Restauração | Backup das configurações anteriores e script para restaurar |

A suspensão automática fica desativada. O menu permite suspender manualmente,
com o Hypridle ativo para bloquear antes de suspender.

Os aplicativos GTK 3 recebem o tema escuro Adwaita dentro da sessão. Aplicativos
com tema próprio, páginas da web, ícones da bandeja e conteúdo de imagens podem
continuar coloridos.

## Atalhos

Super é a tecla Windows.

| Atalho | Ação |
|---|---|
| Super + Enter | Terminal |
| Super + D | Menu de aplicativos |
| Super + B | Firefox |
| Super + E | Gerenciador de arquivos |
| Super + N | Neovim |
| Super + Q | Fechar janela |
| Super + F | Tela cheia |
| Super + V | Alternar janela flutuante |
| Super + J | Alternar a direção da divisão |
| Super + setas | Mudar foco |
| Super + Shift + setas | Mover janela |
| Super + 1 a 9 / 0 | Áreas 1 a 10 |
| Super + Shift + número | Enviar janela para a área |
| Super + botão esquerdo do mouse | Arrastar janela |
| Super + botão direito do mouse | Redimensionar janela |
| Super + L | Bloquear |
| Super + Esc | Menu da sessão |
| Super + Shift + R | Recarregar configurações |
| Super + F1 | Mostrar atalhos |
| Print | Capturar região |
| Shift + Print | Capturar toda a tela |

As teclas multimídia controlam áudio e reprodução. As teclas de brilho funcionam
em dispositivos que oferecem controle de backlight.

## Backup e restauração

Antes de substituir os arquivos, o instalador guarda as pastas anteriores:
hypr, waybar, wofi, mako e alacritty.

O caminho padrão é:

~~~text
~/.local/state/supremo/backups/
~~~

O instalador respeita XDG_CONFIG_HOME e XDG_STATE_HOME quando definidos.
Diretórios extras de configuração ficam preservados. Links simbólicos dessas
cinco pastas são guardados como links, sem modificar o repositório ao qual apontam.

Para restaurar o backup da instalação mais recente, saia do Hyprland e execute:

~~~bash
bash restaurar.sh
~~~

Para escolher um backup anterior:

~~~bash
bash restaurar.sh "/caminho/completo/do/backup"
~~~

A restauração mantém uma cópia das configurações que estavam em uso em
~/.local/state/supremo/antes-de-restaurar/. Os pacotes instalados permanecem
no sistema. Inicie uma nova sessão para aplicar o resultado.

## Personalizar

- Ajustes pessoais: ~/.config/hypr/local.lua.
- Teclado: brasileiro por padrão. Há um exemplo de US internacional em local.lua.
- Margens, bordas, animações e transparência: ~/.config/hypr/hyprland.lua.
- Barra: ~/.config/waybar/config.jsonc e style.css.
- Terminal: ~/.config/alacritty/alacritty.toml.
- Wallpaper: ~/.config/hypr/wallpapers/supremo.png. Após trocar a imagem,
  inicie uma nova sessão para recarregar o wallpaper.

Evite executar o instalador novamente para cada ajuste: ele aplica o pacote
inteiro e cria um novo backup. Edite os arquivos já instalados e recarregue.

## LazyVim e C#

Seu diretório do Neovim é preservado. O pacote contém um tema opcional em:

~~~text
extras/nvim/colors/supremo.lua
extras/nvim/lua/plugins/supremo.lua
~~~

Para usá-lo, copie cada arquivo para o caminho correspondente dentro da sua
configuração do Neovim. Se já houver um arquivo com o mesmo nome, guarde uma
cópia antes. Confira se outro plugin seu não redefine a opção colorscheme.
O tema deixa a sintaxe em tons de cinza e usa negrito, itálico e sublinhado
para diferenciar elementos.

Também está incluída a versão completa do instalador de aplicativos que
preparamos na conversa. Ela instala C#/.NET, dependências de apoio ao LazyVim
e os outros aplicativos que você escolheu:

~~~bash
bash instalar-apps-arch.sh
~~~

Esse segundo script usa o AUR para DeaDBeeF e Hydra. A instalação do rice
usa os repositórios oficiais. Os dois scripts podem ser usados separadamente.
Instalar os pacotes do Neovim não instala a configuração do LazyVim: migre a sua
configuração existente ou siga a instalação oficial.

## Verificação e diagnóstico

Foram verificadas as sintaxes Bash, Python, Lua, JSON e TOML; o fluxo de backup
e restauração foi exercitado em diretórios temporários, incluindo links.
A prévia é uma composição ilustrativa feita a partir da paleta e do layout;
não é uma captura de uma sessão Hyprland executada neste ambiente.

Não foi possível testar esta configuração em uma sessão gráfica real do seu PC.
Após iniciar o Hyprland, confira:

~~~bash
hyprctl configerrors
~~~

Os logs de Waybar, wallpaper, Mako e Hypridle ficam por padrão em
~/.local/state/supremo/logs/.

## Referências

- [Pacote Hyprland do Arch](https://archlinux.org/packages/extra/x86_64/hyprland/)
- [Exemplo oficial do Hyprland 0.56.2](https://github.com/hyprwm/Hyprland/blob/v0.56.2/example/hyprland.lua)
- [Configuração do Hyprland](https://wiki.hypr.land/configuring/)
- [Dispatchers e atalhos](https://wiki.hypr.land/configuring/core/dispatchers/)
- [Waybar](https://github.com/Alexays/Waybar/wiki)
- [Hyprlock](https://github.com/hyprwm/hyprlock)
- [Hypridle](https://github.com/hyprwm/hypridle)
- [LazyVim](https://www.lazyvim.org/)
